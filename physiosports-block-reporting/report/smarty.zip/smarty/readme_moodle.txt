Description of Smarty 2.6.26 library import

* please do not use Smarty in any code, we are going to remove it from distribution in Moodle 2.0
* MDL-20876 - replaced deprecated split() with explode()

skodak 
