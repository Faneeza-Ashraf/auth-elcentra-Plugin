# strlen

Returns the length (number of characters) in the given string, including spaces.

## Basic usage
```smarty
{"Smarty"|strlen} # renders: 6
{156|strlen} # renders: 3
```
