# is_array

Return true if the variable passed to it is an array.

## Basic usage

```smarty
{if $myVar|is_array}it's an array{/if}
```
